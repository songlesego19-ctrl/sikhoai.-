# Sikho AI — phone-only APK build

This is a starter Android app project. It is not a compiled APK yet.

## What it does
- Dark purple/electric-blue chat screen
- Connects to Google's Gemini API
- API key is entered by you and kept only in app memory (not saved to disk)

## Build it using only an Android phone
1. Download and unzip this project.
2. In your phone browser, open https://github.com and create/sign in to an account.
3. Create a **public** repository named `SikhoAI`.
4. Upload the unzipped project files/folders to the repository (GitHub mobile web supports file uploads; if uploading folders is awkward, use the GitHub app or a mobile browser in Desktop site mode).
5. Add this workflow file at `.github/workflows/build.yml` with the contents below.
6. Open the repository's **Actions** tab, choose **Build Sikho AI APK**, and run the workflow.
7. When it finishes, open the successful workflow run, scroll to **Artifacts**, and download `SikhoAI-debug-apk`. Extract the ZIP and install `app-debug.apk`.
8. Android may ask you to allow installs from that browser/file manager. Only enable it for the app you used to download the APK.

## Workflow file: .github/workflows/build.yml

```yaml
name: Build Sikho AI APK
on:
  workflow_dispatch:
  push:
    branches: [ main ]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: android-actions/setup-android@v3
      - uses: gradle/actions/setup-gradle@v4
      - name: Build debug APK
        run: gradle :app:assembleDebug
      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: SikhoAI-debug-apk
          path: app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
```

## Connect the AI
1. Visit https://aistudio.google.com/app/apikey and create an API key.
2. Open Sikho AI, tap Settings, and paste the key.
3. Start chatting.

Free-tier availability, model access, and usage limits are controlled by Google and can change. The API key is a secret: do not share screenshots containing it or publish it in source code. This starter sends requests directly from the app, so it is for personal testing, not a secure public release.

## If the build fails
Check that the repository root contains `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, and the `app` folder. The workflow file must be at `.github/workflows/build.yml`.
