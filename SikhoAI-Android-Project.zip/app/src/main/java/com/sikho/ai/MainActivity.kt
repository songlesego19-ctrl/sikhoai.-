package com.sikho.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

private val bg = Color(0xFF080812)
private val panel = Color(0xFF171629)
private val purple = Color(0xFF9B5CFF)
private val blue = Color(0xFF35C8FF)
private data class ChatLine(val who: String, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SikhoApp() }
    }
}

@Composable
fun SikhoApp() {
    var apiKey by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(true) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf(ChatLine("Sikho", "Hey! I'm Sikho AI. Add your Gemini API key in Settings to start chatting.")) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(primary = purple, background = bg, surface = panel)) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF111027), bg))).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("SIKHO AI", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Text("Your AI companion", color = blue, fontSize = 12.sp)
                }
                TextButton(onClick = { showSettings = !showSettings }) { Text("⚙ Settings", color = blue) }
            }
            if (showSettings) {
                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(top = 14.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Connect free AI", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Paste your Gemini API key. Get one at aistudio.google.com/app/apikey.", color = Color.LightGray, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Gemini API key") }, singleLine = true)
                        Text("Keep your key private. This simple test app stores it only while the app is open.", color = Color(0xFFFFC66D), fontSize = 11.sp)
                    }
                }
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(messages) { m ->
                    val mine = m.who == "You"
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                        Text(m.who, color = if (mine) blue else purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Surface(color = if (mine) Color(0xFF242044) else panel, shape = RoundedCornerShape(16.dp)) {
                            Text(m.text, color = Color.White, modifier = Modifier.padding(12.dp))
                        }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Message Sikho...") }, maxLines = 4)
                Spacer(Modifier.width(8.dp))
                Button(enabled = !busy && input.isNotBlank(), onClick = {
                    val question = input.trim()
                    input = ""
                    messages.add(ChatLine("You", question))
                    busy = true
                    scope.launch {
                        val answer = withContext(Dispatchers.IO) { askGemini(apiKey, messages.filter { it.who != "Sikho" }.takeLast(20)) }
                        messages.add(ChatLine("Sikho", answer))
                        busy = false
                    }
                }) { Text(if (busy) "..." else "Send") }
            }
        }
    }
}

private fun askGemini(key: String, history: List<ChatLine>): String {
    if (key.isBlank()) return "Open Settings and add your Gemini API key first."
    return try {
        val parts = JSONArray()
        history.drop(1).forEach { line ->
            parts.put(JSONObject().put("role", if (line.who == "You") "user" else "model")
                .put("parts", JSONArray().put(JSONObject().put("text", line.text))))
        }
        val body = JSONObject().put("contents", parts)
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent")
            .addHeader("x-goog-api-key", key)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        OkHttpClient().newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) "AI service error (${response.code}): check your API key, quota, or internet."
            else JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        }
    } catch (e: Exception) { "Couldn't connect. Check your internet and API key, then try again." }
}
